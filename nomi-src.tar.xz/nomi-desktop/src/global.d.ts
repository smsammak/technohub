interface Window {
 nomi?:{
  fetchFigma:(args:{fileKey:string;nodeId:string;token:string})=>Promise<{node:import('./qa').FigmaNode;name:string;fetchedAt:string}>;
  saveReport:(args:{text:string;suggestedName:string})=>Promise<boolean>;
  platform:string;
 }
}
