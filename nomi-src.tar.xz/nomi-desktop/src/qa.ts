export type FigmaNode = {
 id:string; name:string; type:string; visible?:boolean; children?:FigmaNode[];
 absoluteBoundingBox?:{x:number;y:number;width:number;height:number};
 layoutMode?:string; fills?:Array<{type?:string;visible?:boolean;boundVariables?:Record<string,unknown>}>;
 boundVariables?:Record<string,unknown>; componentId?:string;
};
export type Issue = { id:string; nodeId:string; nodeName:string; title:string; detail:string; severity:'high'|'medium'|'low'; rule:string; suggestion:string };
export type Audit = {issues:Issue[]; scanned:number; instances:number; frames:number; hidden:number; timestamp:string};
const genericName=/^(frame|group|rectangle|ellipse|vector|line|text|component|instance)\s+\d+(?:\s*\d+)*$/i;
const geometric=(n:FigmaNode)=>n.absoluteBoundingBox;
const isContainer=(n:FigmaNode)=>['FRAME','COMPONENT','INSTANCE','GROUP'].includes(n.type);
export function runAudit(root:FigmaNode):Audit {
 const issues:Issue[]=[];let scanned=0,instances=0,frames=0,hidden=0;
 function add(n:FigmaNode,rule:string,title:string,detail:string,severity:Issue['severity'],suggestion:string){issues.push({id:`${n.id}-${rule}`,nodeId:n.id,nodeName:n.name,title,detail,severity,rule,suggestion});}
 function visit(n:FigmaNode,depth:number){
  if(scanned>=25000) return;
  scanned++;
  if(n.type==='INSTANCE') instances++;
  if(n.type==='FRAME') frames++;
  if(n.visible===false) hidden++;
  if(genericName.test(n.name)) add(n,'generic-name','Generic layer name',`“${n.name}” doesn’t describe the layer’s purpose.`,'medium','Rename to a semantic name that describes the content or role.');
  if(n.visible===false && depth<=3) add(n,'hidden-layer','Hidden top-level layer',`“${n.name}” is hidden. Confirm it still belongs in the source design.`,'low','Review before removing. Hidden layers may be intentional states.');
  if(n.type==='FRAME' && (n.children?.length||0)>=3 && (n.layoutMode===undefined || n.layoutMode==='NONE')) add(n,'layout-review','Layout review recommended','This multi-child frame does not expose an active Auto Layout mode.','low','Check whether Auto Layout improves resizing behavior.');
  // Only a conservative bounds check: nesting and component constraints can intentionally extend outside parents.
  if(n.type==='FRAME' && n.children && geometric(n)) {
    const b=geometric(n)!;
    for(const c of n.children){const cb=geometric(c);if(!cb || c.visible===false) continue;
      const overflow=cb.x<b.x-1 || cb.y<b.y-1 || cb.x+cb.width>b.x+b.width+1 || cb.y+cb.height>b.y+b.height+1;
      if(overflow) add(c,'overflow-review','Possible frame overflow',`“${c.name}” extends beyond the bounds of “${n.name}”.`,'medium','Inspect clipping, positioning, and intended overlays.');
    }
  }
  if(n.type==='RECTANGLE' && n.fills?.some(f=>f.type==='SOLID' && f.visible!==false && !f.boundVariables) && !n.boundVariables?.fills)
    add(n,'raw-fill','Unbound solid fill (review)','This rectangle may use a direct solid color instead of a Figma variable.','low','Compare with approved color tokens; do not replace automatically.');
  if(isContainer(n) && depth<60) for(const c of n.children||[]) visit(c,depth+1);
 }
 visit(root,0);
 issues.sort((a,b)=>({high:0,medium:1,low:2}[a.severity]-{high:0,medium:1,low:2}[b.severity]));
 return {issues,scanned,instances,frames,hidden,timestamp:new Date().toISOString()};
}
export function parseFigmaInput(json:unknown):FigmaNode {
 if(!json || typeof json!=='object') throw new Error('JSON must contain a Figma document or node.');
 const data=json as any;
 const node=data.document || data.node || (data.nodes ? Object.values(data.nodes)[0] && (Object.values(data.nodes)[0] as any).document : null) || data;
 if(!node || !node.id || !node.type || !node.name) throw new Error('No valid Figma node found. Import a Figma API JSON response.');
 return node;
}
export function parseFigmaUrl(url:string):{fileKey:string;nodeId:string}{
 const u=new URL(url);
 if(!/(^|\.)figma\.com$/.test(u.hostname)) throw new Error('Use a figma.com design URL.');
 const match=u.pathname.match(/^\/design\/([a-zA-Z0-9]{22,128})(?:\/|$)/);
 const id=u.searchParams.get('node-id');
 if(!match || !id || !/^\d+[-:]\d+$/.test(id)) throw new Error('Include a Figma design URL with node-id.');
 return {fileKey:match[1],nodeId:id.replace('-',':')};
}
