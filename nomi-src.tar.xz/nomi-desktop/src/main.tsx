import React,{useMemo,useRef,useState} from 'react';
import {createRoot} from 'react-dom/client';
import { Activity, ArrowDownToLine, ArrowRight, CheckCircle2, ChevronDown, CircleAlert, Code2, Command, Component, ExternalLink, FileJson, FileSearch, Figma, FolderOpen, Layers3, LayoutDashboard, LockKeyhole, MessageCircle, MonitorSmartphone, Play, Search, Settings2, ShieldCheck, Sparkles, UploadCloud, WandSparkles, X } from 'lucide-react';
import {runAudit,parseFigmaInput,parseFigmaUrl,type Audit,type Issue,type FigmaNode} from './qa';
import {sample,SAMPLE_URL} from './demo';
import './style.css';
type Tab='overview'|'audit'|'connection'|'activity';
const iconSize=18;
const SEVERITY:{[K in Issue['severity']]:string}={high:'Critical',medium:'Review',low:'Suggestion'};
function App(){
 const [tab,setTab]=useState<Tab>('overview');
 const [url,setUrl]=useState(SAMPLE_URL);
 const [token,setToken]=useState('');
 const [root,setRoot]=useState<FigmaNode>(sample);
 const [source,setSource]=useState<'sample'|'live'|'import'>('sample');
 const [sourceName,setSourceName]=useState('Techno HUB / CRM — partial metadata sample');
 const [audit,setAudit]=useState<Audit|null>(null);
 const [busy,setBusy]=useState(false);
 const [error,setError]=useState('');
 const [search,setSearch]=useState('');
 const [filter,setFilter]=useState('all');
 const [logs,setLogs]=useState<string[]>(['Workspace initialized. Read-only sample loaded.']);
 const fileRef=useRef<HTMLInputElement|null>(null);
 const addLog=(s:string)=>setLogs(old=>[`${new Date().toLocaleTimeString()} — ${s}`,...old].slice(0,50));
 const startAudit=()=>{const report=runAudit(root);setAudit(report);setTab('audit');addLog(`Scanned ${report.scanned} layers; flagged ${report.issues.length} review items.`);};
 const filtered=useMemo(()=>audit?.issues.filter(x=>(filter==='all'||x.severity===filter) && `${x.title} ${x.nodeName} ${x.rule}`.toLowerCase().includes(search.toLowerCase()))||[],[audit,filter,search]);
 const liveConnect=async()=>{
  setError('');setBusy(true);
  try{
   const {fileKey,nodeId}=parseFigmaUrl(url);
   if(!window.nomi) throw new Error('Live Figma connection requires the installed desktop app. Use JSON import in web preview.');
   const data=await window.nomi.fetchFigma({fileKey,nodeId,token});
   setRoot(data.node);setSource('live');setSourceName(`${data.name} / ${data.node.name}`);setToken('');setAudit(null);setTab('overview');addLog(`Connected to Figma node ${nodeId}.`);
  }catch(e){setError(e instanceof Error?e.message:'Unable to connect.');}
  finally{setBusy(false);}
 };
 const importJson=async(e:React.ChangeEvent<HTMLInputElement>)=>{
  const file=e.target.files?.[0];if(!file)return;
  try{if(file.size>25_000_000)throw new Error('JSON file exceeds 25 MB.');
   const input=JSON.parse(await file.text());const node=parseFigmaInput(input);
   setRoot(node);setSource('import');setSourceName(`${file.name} / ${node.name}`);setAudit(null);setError('');setTab('overview');addLog(`Imported ${file.name} for offline audit.`);
  }catch(err){setError(err instanceof Error?err.message:'Invalid JSON.');setTab('connection');}
  e.target.value='';
 };
 const exportReport=async()=>{
  if(!audit)return;
  const data=JSON.stringify({tool:'Nomi Design QA',version:'0.1.0',source,sourceName,rootId:root.id,...audit},null,2);
  if(window.nomi){await window.nomi.saveReport({text:data,suggestedName:'nomi-design-qa.json'});return;}
  const blob=new Blob([data],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='nomi-design-qa.json';a.click();URL.revokeObjectURL(a.href);
 };
 const nav:[Tab,string,React.ReactNode][]=[['overview','Overview',<LayoutDashboard size={iconSize}/>],['audit','Design QA',<ShieldCheck size={iconSize}/>],['connection','Figma connection',<Figma size={iconSize}/>],['activity','Activity',<Activity size={iconSize}/>]];
 return <div className="shell">
  <aside className="sidebar">
   <div className="brand"><div className="brandmark"><Sparkles size={23}/></div><div><strong>Nomi</strong><small>Design companion</small></div></div>
   <div className="nav-label">WORKSPACE</div>
   <nav>{nav.map(([key,label,icon])=><button key={key} onClick={()=>setTab(key)} className={`nav ${tab===key?'active':''}`}>{icon}<span>{label}</span>{key==='audit'&&audit?<b>{audit.issues.length}</b>:null}</button>)}</nav>
   <div className="sidebar-bottom"><div className="mini-card"><div className="pulse"><span/></div><div><strong>Local workspace</strong><small>Safe, read-only analysis</small></div></div><p className="version">NOMI DESKTOP · v0.1.0</p></div>
  </aside>
  <main className="main">
   <header className="topbar"><div className="crumb"><span>Workspace</span><span className="slash">/</span><strong>{tab==='overview'?'Overview':tab==='audit'?'Design QA':tab==='connection'?'Figma connection':'Activity log'}</strong></div><div className="top-actions"><span className={`status-dot ${source==='live'?'live':''}`}/><span>{source==='live'?'Live Figma data':source==='import'?'Imported JSON':'Sample mode'}</span><span className="avatar">N</span></div></header>
   <div className="content">
    {tab==='overview' && <>
     <div className="welcome"><div><div className="eyebrow"><Sparkles size={15}/> YOUR AI DESIGN TEAMMATE</div><h1>Good to see you.<br/><span>Ready to make design work lighter?</span></h1><p>Connect a Figma frame, run a structured design audit, and spend less time on repetitive checks.</p><div className="welcome-actions"><button className="primary" onClick={startAudit}><Play size={16} fill="currentColor"/> Run Design QA <ArrowRight size={16}/></button><button className="secondary" onClick={()=>setTab('connection')}><Figma size={17}/> Connect Figma</button></div></div><div className="orb-wrap"><div className="orb"><span className="orb-eye"/><span className="orb-eye"/><span className="orb-smile"/></div><span className="orbit orbit-1"/><span className="orbit orbit-2"/><Sparkles className="orb-star" size={27}/></div></div>
     <div className="section-heading"><div><h2>Design toolkit</h2><p>Start with a real QA scan. Other capabilities will arrive in future versions.</p></div></div>
     <div className="toolgrid"><button className="toolcard" onClick={startAudit}><span className="toolicon purple"><FileSearch size={24}/></span><strong>Design QA</strong><small>Find naming, layout and structure issues</small><span className="cardlink">Run audit <ArrowRight size={15}/></span></button><button className="toolcard" onClick={()=>setTab('connection')}><span className="toolicon blue"><Figma size={24}/></span><strong>Figma integration</strong><small>Inspect a selected frame using a token</small><span className="cardlink">Connect <ArrowRight size={15}/></span></button><div className="toolcard disabled"><span className="toolicon peach"><MonitorSmartphone size={24}/></span><strong>Responsive builder</strong><small>Desktop to mobile, based on design rules</small><span className="soon">Planned</span></div><div className="toolcard disabled"><span className="toolicon mint"><Layers3 size={24}/></span><strong>UI state generator</strong><small>Loading, empty, error and success states</small><span className="soon">Planned</span></div></div>
     <div className="workspace-card"><div className="workspace-icon"><Component size={23}/></div><div className="workspace-info"><div className="workspace-title"><h3>Current design source</h3><span className="tag">{source==='sample'?'PARTIAL SAMPLE':source==='live'?'LIVE':'IMPORTED'}</span></div><p title={sourceName}>{sourceName}</p><small>Root node: <code>{root.id}</code> · Analysis only — no Figma changes</small></div><button className="outline" onClick={()=>setTab('connection')}>Change source <ArrowRight size={15}/></button></div>
    </>}
    {tab==='connection' && <div className="page-narrow"><div className="eyebrow"><Figma size={15}/> CONNECTION</div><h1>Connect your design source</h1><p className="page-desc">Use a Figma personal access token for read-only inspection, or import a JSON response to run offline QA.</p><div className="panel"><div className="panel-head"><div className="panel-icon"><Figma size={22}/></div><div><h2>Figma REST connection</h2><p>Runs only inside the desktop app. Token is used for this request and never written to disk.</p></div></div><label>Figma design URL <input value={url} onChange={e=>setUrl(e.target.value)} placeholder="https://www.figma.com/design/...?...node-id=..."/></label><label>Personal access token <input value={token} onChange={e=>setToken(e.target.value)} type="password" autoComplete="off" placeholder="figd_••••••••••••••••"/></label><div className="hint"><LockKeyhole size={16}/> Request goes directly from the desktop app to Figma. Provide a read-only token with access to this file.</div><button className="primary" onClick={liveConnect} disabled={busy||!token.trim()}>{busy?'Connecting…':'Connect & load frame'} <ArrowRight size={16}/></button></div><div className="panel import-panel"><div className="panel-head"><div className="panel-icon"><FileJson size={22}/></div><div><h2>Import Figma JSON</h2><p>Offline fallback. Accepts a node document or Figma REST API response.</p></div></div><input hidden type="file" ref={fileRef} onChange={importJson} accept=".json,application/json"/><button className="secondary" onClick={()=>fileRef.current?.click()}><UploadCloud size={18}/> Choose JSON file</button><button className="text-button" onClick={()=>{setRoot(sample);setSource('sample');setSourceName('Techno HUB / CRM — partial metadata sample');setAudit(null);setTab('overview');addLog('Restored read-only Techno HUB sample.');}}>Restore Techno HUB sample</button></div>{error&&<div className="error"><CircleAlert size={17}/>{error}<button onClick={()=>setError('')}><X size={16}/></button></div>}</div>}
    {tab==='audit' && <><div className="audit-title"><div><div className="eyebrow"><ShieldCheck size={15}/> DESIGN QA</div><h1>Design health report</h1><p className="page-desc">Rule-based checks. Findings are review candidates, not confirmed design defects.</p></div><div className="audit-actions"><button className="secondary" onClick={startAudit}><Play size={16}/> {audit?'Scan again':'Run first scan'}</button><button className="outline" disabled={!audit} onClick={exportReport}><ArrowDownToLine size={16}/> Export JSON</button></div></div>{audit?<><div className="metrics"><div className="metric"><span>Layers scanned</span><strong>{audit.scanned}</strong><small>Inside selected node</small></div><div className="metric"><span>Review items</span><strong>{audit.issues.length}</strong><small>Non-destructive findings</small></div><div className="metric"><span>Instances</span><strong>{audit.instances}</strong><small>Reusable components</small></div><div className="metric"><span>Hidden layers</span><strong>{audit.hidden}</strong><small>May be intentional</small></div></div><div className="results"><div className="results-head"><div><h2>Findings <span className="count">{filtered.length}</span></h2><p>{sourceName}</p></div><div className="results-controls"><div className="searchbox"><Search size={16}/><input aria-label="Search issues" placeholder="Search findings" value={search} onChange={e=>setSearch(e.target.value)}/></div><div className="filter-wrap"><select aria-label="Filter by severity" value={filter} onChange={e=>setFilter(e.target.value)}><option value="all">All levels</option><option value="high">Critical</option><option value="medium">Review</option><option value="low">Suggestion</option></select><ChevronDown size={14}/></div></div></div><div className="issues">{filtered.length?filtered.map(i=><div className="issue" key={i.id}><div className={`severity ${i.severity}`}>{i.severity==='high'?<CircleAlert size={17}/>:<FileSearch size={17}/>}</div><div className="issue-content"><div className="issue-top"><strong>{i.title}</strong><span className={`pill ${i.severity}`}>{SEVERITY[i.severity]}</span></div><div className="node-name"><Code2 size={14}/>{i.nodeName} <span>· {i.nodeId}</span></div><p>{i.detail}</p><div className="suggestion"><WandSparkles size={14}/>{i.suggestion}</div></div></div>):<div className="empty"><CheckCircle2 size={28}/><strong>No matching findings</strong><p>Try another filter or scan a different frame.</p></div>}</div></div></>:<div className="no-audit"><div className="no-audit-icon"><FileSearch size={33}/></div><h2>No audit yet</h2><p>Run a scan to see real rule-based findings for your current source.</p><button className="primary" onClick={startAudit}>Run Design QA <ArrowRight size={16}/></button></div>}</>}
    {tab==='activity'&&<div className="page-narrow"><div className="eyebrow"><Activity size={15}/> ACTIVITY</div><h1>Workspace activity</h1><p className="page-desc">Local session activity only. Logs are not synced or persisted.</p><div className="panel log-panel">{logs.map((s,i)=><div className="log-line" key={i}><span className="log-dot"/>{s}</div>)}</div></div>}
   </div>
  </main>
 </div>;
}
createRoot(document.getElementById('root')!).render(<React.StrictMode><App/></React.StrictMode>);
