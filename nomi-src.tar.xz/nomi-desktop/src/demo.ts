import type {FigmaNode} from './qa.ts';
// Read-only sample reconstructed from actual Figma metadata for the user-provided CRM frame.
// Intentionally a partial metadata snapshot: not a complete Figma REST response.
export const sample:FigmaNode={id:'10773:67294',name:'Product',type:'FRAME',children:[
 {id:'10884:74924',name:'Header',type:'INSTANCE'},
 {id:'10773:67320',name:'Frame 1410076297',type:'FRAME',children:[
  {id:'10773:67321',name:'Frame 1410076287',type:'FRAME',children:[
   {id:'12604:257798',name:'Header',type:'INSTANCE'},
   {id:'10773:67327',name:'Background',type:'FRAME',children:[
    {id:'11096:19734',name:'cards',type:'FRAME',children:[
     {id:'12735:11781',name:'cards',type:'INSTANCE'},{id:'12735:11772',name:'cards',type:'INSTANCE'},{id:'12735:11763',name:'cards',type:'INSTANCE'}]},
    {id:'10773:67351',name:'Frame 1410076605',type:'FRAME',children:[
     {id:'10891:265389',name:'Frame 1410076608',type:'FRAME',children:[
      {id:'10891:265390',name:'Frame 1000005793',type:'FRAME',children:[
       {id:'12625:315548',name:'Form=Text-Icon, Type=primary, State=Default, Size=48',type:'INSTANCE',visible:false},
       {id:'10891:265391',name:'تماس‌های اخیر',type:'TEXT'},
       {id:'10893:265701',name:'phone 2',type:'INSTANCE',visible:false},
       {id:'12625:315547',name:'Form=Text-Icon, Type=primary, State=Default, Size=48',type:'INSTANCE'}]},
      {id:'10891:265394',name:'Frame 1410076494',type:'FRAME',children:[
       {id:'10893:265853',name:'call',type:'INSTANCE'},{id:'11096:19853',name:'call',type:'INSTANCE'},
       {id:'10893:265882',name:'call',type:'INSTANCE'},{id:'10893:265823',name:'call',type:'INSTANCE'},
       {id:'12622:280309',name:'call',type:'INSTANCE'},{id:'12622:280323',name:'call',type:'INSTANCE'},
       {id:'12622:280337',name:'call',type:'INSTANCE'}]}]},
     {id:'12737:12045',name:'call',type:'INSTANCE'}]}]}]},
  {id:'18466:309530',name:'Sidebar',type:'INSTANCE'}]},
 {id:'10773:67413',name:'Alert',type:'INSTANCE',visible:false}
]};
export const SAMPLE_URL='https://www.figma.com/design/wIdOV7wYmuFCDTmAFfwpEH/Techno-HUB--Project?node-id=10773-67294';
