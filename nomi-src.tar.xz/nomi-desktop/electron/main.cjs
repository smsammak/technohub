const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const fs = require('node:fs/promises');

const isDev = !app.isPackaged;
function createWindow() {
  const win = new BrowserWindow({
    width: 1340, height: 860, minWidth: 1020, minHeight: 680,
    backgroundColor: '#0b0e18', title: 'Nomi',
    webPreferences: { preload: path.join(__dirname, 'preload.cjs'), contextIsolation: true, nodeIntegration: false, sandbox: true }
  });
  win.removeMenu();
  win.webContents.setWindowOpenHandler(() => ({action:'deny'}));
  win.webContents.on('will-navigate', (event) => event.preventDefault());
  if (isDev) win.loadURL('http://127.0.0.1:5173');
  else win.loadFile(path.join(__dirname, '../dist/index.html'));
}

ipcMain.handle('figma:fetch', async (_event, input) => {
  const { fileKey, nodeId, token } = input || {};
  if (typeof fileKey !== 'string' || !/^[a-zA-Z0-9]{22,128}$/.test(fileKey)) throw new Error('Invalid Figma file key');
  if (typeof nodeId !== 'string' || !/^\d+[:\-]\d+$/.test(nodeId)) throw new Error('Invalid Figma node id');
  if (typeof token !== 'string' || token.trim().length < 10 || token.length > 500) throw new Error('Enter a valid personal access token');
  const endpoint = `https://api.figma.com/v1/files/${fileKey}/nodes?ids=${encodeURIComponent(nodeId.replace('-', ':'))}`;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 25000);
  try {
    const response = await fetch(endpoint, {headers: {'X-Figma-Token':token.trim()}, signal:controller.signal});
    if (!response.ok) {
      if(response.status === 403 || response.status === 401) throw new Error('Figma access denied. Check token permissions and file access.');
      if(response.status === 404) throw new Error('File or node was not found.');
      throw new Error(`Figma API returned HTTP ${response.status}`);
    }
    const data = await response.json();
    const node = data.nodes?.[nodeId.replace('-', ':')]?.document;
    if (!node) throw new Error('Selected node is missing in API response');
    return {node, name:data.name || 'Figma file', fetchedAt:new Date().toISOString()};
  } finally { clearTimeout(timer); }
});

ipcMain.handle('report:save', async (_event, {text, suggestedName}) => {
  if(typeof text !== 'string' || text.length > 15_000_000) throw new Error('Invalid report');
  const name = typeof suggestedName === 'string' && /^[\w.\-]+$/.test(suggestedName) ? suggestedName : 'nomi-qa-report.json';
  const result = await dialog.showSaveDialog({title:'Export Nomi report', defaultPath:name, filters:[{name:'JSON',extensions:['json']}]});
  if(result.canceled || !result.filePath) return false;
  await fs.writeFile(result.filePath,text,'utf8'); return true;
});
app.whenReady().then(() => { createWindow(); app.on('activate',()=>{if(BrowserWindow.getAllWindows().length===0) createWindow();}); });
app.on('window-all-closed', () => {if(process.platform !== 'darwin') app.quit();});
