const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('nomi', {
  fetchFigma: (args) => ipcRenderer.invoke('figma:fetch', args),
  saveReport: (data) => ipcRenderer.invoke('report:save', data),
  platform: process.platform,
});
