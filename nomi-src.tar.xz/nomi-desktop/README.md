# Nomi Desktop — Design QA MVP

A working **read-only Figma QA companion**, built with Electron, React, TypeScript and Vite. This is the first executable foundation of Nomi, not a full autonomous design agent.

## What's implemented

- Windows desktop app shell and dashboard
- Figma REST read-only connection to a selected node using a personal access token
- Offline import of Figma REST JSON
- Rule-based QA: generic layer names, high-level hidden layers, frames needing Auto Layout review, potential bounds overflow, direct rectangle fills needing token review
- Layer/instance counts, searchable results, severity filters, JSON export, session activity
- Partial sample based on **Techno HUB CRM** node `10773:67294` from the provided Figma file
- Native Windows installer workflow via GitHub Actions

**Not yet implemented:** AI model inference, design mutations, responsive generation, states generation, automatic fixes, credential storage, OAuth, full token library auditing. Results are heuristic review suggestions; some are intentional design choices.

## Requirements

- Node.js 22+
- For desktop development: Windows 10/11 (or another OS supported by Electron)
- To produce `.exe`: Windows build environment or GitHub Actions

## Run

```bash
npm install --no-audit --no-fund
npm run dev
```

The desktop app opens via Electron. `npm run web:dev` runs a browser-only preview (live Figma access needs the desktop IPC backend).

## Connect Figma

1. Open the **Figma connection** tab.
2. Paste a Figma **design URL with `node-id`**.
3. Create a Figma personal access token with read access to the file, and enter it.
4. Select **Connect & load frame**.
5. Run **Design QA**; export report as JSON.

The token stays in memory for a single request; it is not persisted to disk or logged. The Electron main process sends it directly to `https://api.figma.com`. Do not embed tokens in shared source code or exported reports. You must have access to the Figma file and an API token permitted to read it. Figma REST API limits may apply. The connection isn't verified until a valid token is supplied at runtime.

## Build Windows installer

```bash
npm install --no-audit --no-fund
npm test
npm run dist:win
```

The `.exe` installer will be in `release/`. Or upload this repository to GitHub and run **Actions → Build Nomi Windows installer → Run workflow**; download the artifact. Windows installers generated without a code signing certificate may show security warnings; signing and an updater are production follow-up work.

## Safety

This version **never writes to Figma**. JSON import and reporting are local. The sample bundled in `src/demo.ts` is **partial metadata** from the supplied CRM frame and is not a substitute for a complete live audit.

## Roadmap

1. Connect Figma components, variables and design token registry.
2. Deterministic rules with fewer false positives and user-approved conventions.
3. AI-backed explanations and task planning.
4. Draft-only responsive/state generation and explicit approvals.
5. Snapshot/restore strategy, production auth and signed Windows builds.

## Verification status

The QA engine is tested with Node.js built-in test runner. UI package installation and Electron runtime were not verified in the creation environment because npm registry DNS was unavailable. The Windows CI workflow will install packages and build the installer on a Windows runner. No `.exe` is included in this source archive.
